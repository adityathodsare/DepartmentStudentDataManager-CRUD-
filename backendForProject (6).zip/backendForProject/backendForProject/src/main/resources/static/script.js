const apiUrl = 'http://localhost:8080/api/students';

// Add Student or Update Student
document.getElementById('studentForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const updateIdInput = document.getElementById('updateStudentId');

    if (updateIdInput) {
        // If there's an updateId, call the updateStudent function
        updateStudent();
    } else {
        // Otherwise, add a new student
        const studentData = {
            firstName: document.getElementById('firstName').value,
            lastName: document.getElementById('lastName').value,
            yearOfStudy: document.getElementById('yearOfStudy').value,
            phoneNo: document.getElementById('phoneNo').value,
            email: document.getElementById('email').value,
            address: document.getElementById('address').value,
            electiveSub1: document.getElementById('electiveSub1').value,
            electiveSub2: document.getElementById('electiveSub2').value,
            cgpa1: document.getElementById('cgpa1').value,
            cgpa2: document.getElementById('cgpa2').value,
            cgpa3: document.getElementById('cgpa3').value,
            cgpa4: document.getElementById('cgpa4').value
        };

        fetch(apiUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(studentData),
        })
        .then(response => response.json())
        .then(data => {
            alert('Student added successfully!');
            document.getElementById('studentForm').reset();
            getAllStudents(); // Refresh student list after adding
        })
        .catch(error => {
            console.error('Error:', error);
        });
    }
});

// Fetch All Students
function getAllStudents() {
    fetch(apiUrl)
        .then(response => response.json())
        .then(students => {
            displayStudents(students);
        })
        .catch(error => {
            console.error('Error:', error);
        });
}

// Display Students
function displayStudents(students) {
    const studentsDisplay = document.getElementById('studentsDisplay');
    studentsDisplay.innerHTML = '';

    if (students.length === 0) {
        studentsDisplay.innerHTML = '<p>No students found.</p>';
        return;
    }

    const ul = document.createElement('ul');

    students.forEach(student => {
        const li = document.createElement('li');
        li.textContent = `${student.firstName} ${student.lastName} (${student.yearOfStudy})`;

        // Create Edit button
        const editButton = document.createElement('button');
        editButton.textContent = 'Edit';
        editButton.onclick = () => editStudent(student.id);
        li.appendChild(editButton);

        // Create Delete button
        const deleteButton = document.createElement('button');
        deleteButton.textContent = 'Delete';
        deleteButton.onclick = () => deleteStudent(student.id);
        li.appendChild(deleteButton);

        ul.appendChild(li);
    });

    studentsDisplay.appendChild(ul);
}

// Edit Student
function editStudent(id) {
    fetch(`${apiUrl}/${id}`)
        .then(response => response.json())
        .then(student => {
            document.getElementById('firstName').value = student.firstName;
            document.getElementById('lastName').value = student.lastName;
            document.getElementById('yearOfStudy').value = student.yearOfStudy;
            document.getElementById('phoneNo').value = student.phoneNo;
            document.getElementById('email').value = student.email;
            document.getElementById('address').value = student.address;
            document.getElementById('electiveSub1').value = student.electiveSub1;
            document.getElementById('electiveSub2').value = student.electiveSub2;
            document.getElementById('cgpa1').value = student.cgpa1;
            document.getElementById('cgpa2').value = student.cgpa2;
            document.getElementById('cgpa3').value = student.cgpa3;
            document.getElementById('cgpa4').value = student.cgpa4;

            // Show update button
            document.getElementById('updateButton').style.display = 'inline-block';
            document.getElementById('studentForm').setAttribute('data-update-id', id);
        })
        .catch(error => {
            console.error('Error:', error);
        });
}

// Update Student
function updateStudent() {
    const id = document.getElementById('studentForm').getAttribute('data-update-id');
    const studentData = {
        firstName: document.getElementById('firstName').value,
        lastName: document.getElementById('lastName').value,
        yearOfStudy: document.getElementById('yearOfStudy').value,
        phoneNo: document.getElementById('phoneNo').value,
        email: document.getElementById('email').value,
        address: document.getElementById('address').value,
        electiveSub1: document.getElementById('electiveSub1').value,
        electiveSub2: document.getElementById('electiveSub2').value,
        cgpa1: document.getElementById('cgpa1').value,
        cgpa2: document.getElementById('cgpa2').value,
        cgpa3: document.getElementById('cgpa3').value,
        cgpa4: document.getElementById('cgpa4').value
    };

    fetch(`${apiUrl}/${id}`, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(studentData),
    })
    .then(response => response.json())
    .then(data => {
        alert('Student updated successfully!');
        document.getElementById('studentForm').reset();
        document.getElementById('updateButton').style.display = 'none';
        getAllStudents(); // Refresh student list after updating
    })
    .catch(error => {
        console.error('Error:', error);
    });
}

// Delete Student
function deleteStudent(id) {
    if (confirm('Are you sure you want to delete this student?')) {
        fetch(`${apiUrl}/${id}`, {
            method: 'DELETE'
        })
        .then(response => {
            if (response.ok) {
                alert('Student deleted successfully!');
                getAllStudents(); // Refresh student list after deletion
            }
        })
        .catch(error => {
            console.error('Error:', error);
        });
    }
}

// Get Student by ID
function getStudentById() {
    const id = document.getElementById('studentId').value;
    fetch(`${apiUrl}/${id}`)
        .then(response => response.json())
        .then(student => {
            const studentDetails = document.getElementById('studentDetails');
            studentDetails.innerHTML = `<h3>Student Details:</h3>
                                        <p><strong>First Name:</strong> ${student.firstName}</p>
                                        <p><strong>Last Name:</strong> ${student.lastName}</p>
                                        <p><strong>Year of Study:</strong> ${student.yearOfStudy}</p>
                                        <p><strong>Phone Number:</strong> ${student.phoneNo}</p>
                                        <p><strong>Email:</strong> ${student.email}</p>
                                        <p><strong>Address:</strong> ${student.address}</p>
                                        <p><strong>Elective Subject 1:</strong> ${student.electiveSub1}</p>
                                        <p><strong>Elective Subject 2:</strong> ${student.electiveSub2}</p>
                                        <p><strong>CGPA FE:</strong> ${student.cgpa1}</p>
                                        <p><strong>CGPA SE:</strong> ${student.cgpa2}</p>
                                        <p><strong>CGPA TE:</strong> ${student.cgpa3}</p>
                                        <p><strong>CGPA BE:</strong> ${student.cgpa4}</p>`;
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Student not found!');
        });
}

// Filter Students by Year of Study
function filterStudents() {
    const year = document.getElementById('filterYear').value;
    const filteredUrl = year ? `${apiUrl}/yearOfStudy${year}` : apiUrl;

    fetch(filteredUrl)
        .then(response => response.json())
        .then(students => {
            displayStudents(students);
        })
        .catch(error => {
            console.error('Error:', error);
        });
}
