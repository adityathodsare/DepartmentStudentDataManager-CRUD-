package net.DBMSprojectAny.backendForProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendForProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
